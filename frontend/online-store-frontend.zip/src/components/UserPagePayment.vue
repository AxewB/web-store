<template>
  <div>
    Payment
  </div>
</template>

<script setup>

</script>
