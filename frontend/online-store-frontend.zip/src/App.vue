<template>
  <v-app >
    <v-main class="d-flex flex-row justify-center"
    >
    <v-sheet width="1200px" class="bg-transparent">
      <router-view/>
    </v-sheet>
    </v-main>
  </v-app>
</template>

<script setup>
  //
</script>
