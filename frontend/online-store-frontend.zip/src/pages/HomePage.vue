<template>
  <div>
    <PageHeader/>
  </div>
</template>

<script setup>
import PageHeader from '@/components/PageHeader.vue'
  //
</script>
