<template>
  <v-sheet>
    <PageHeader/>
    cart
  </v-sheet>
</template>

<script setup>
import PageHeader from '@/components/PageHeader.vue'

</script>
